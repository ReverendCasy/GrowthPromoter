#!/usr/bin/env python3

from functools import wraps, update_wrapper
from typing import Any, Callable

import click
import multiprocessing as mp
import pathos.multiprocessing as mpp
import time

"""
Searches for sequences from the query set in a subject database
either in parallel or via a single thread
"""

def findSeq(el: str, db: set) -> str:
    if el in db:
        return el


def finderFunc(db: set) -> str:
    def decor(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            el = func(*args, **kwargs)
            if el:
                return findSeq(el, db)
        return wrapper
    return decor


def singleCoreSearch(query: set, db: set) -> set:
    """
    Searches for occurrences of each set element of the *query*
    set in a *db* set. Preferable for small queries
    """

    @finderFunc(db = db)
    def poppingFunc(query: set):
        if len(query) > 0:
            return query.pop()


    output = set()
    while query:
        result = poppingFunc(query)
        if result:
            output.add(result)
    return output


def multiSearch(query: set, db: set, threads: int=None) -> set:
    """
    Parallels the search process. Preferable when working
    with massive loads of query data
    """

    @finderFunc(db = db)
    def poppingFunc(query: Any):
        if query.qsize() > 0:
            return query.get()

    if not threads:
        cpus = mp.cpu_count()
        threads = min(cpus, len(query))
        del cpus

    with mpp.ProcessPool(processes=threads) as pool:
        m = mp.Manager()
        q = m.Queue()
        qsize = len(query)
        for i in query:
            q.put(i)
        del query
        prcs = [pool.apipe(poppingFunc, q) for _ in range(qsize)]
        all_res = set([x.get() for x in prcs if x.get()])
    return all_res
