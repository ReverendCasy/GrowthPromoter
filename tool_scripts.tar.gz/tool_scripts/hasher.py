#!/usr/bin/env python3

from Bio import SeqIO
from typing import Generator

import click
import hashlib
import os

"""
Hashes the database and the query
"""

def hashSeqs(seq: Generator) -> str:
    hasher = hashlib.md5()
    seq = seq.encode('utf-8')
    hasher.update(seq)
    return hasher.hexdigest()


@click.command()
@click.argument('seqs', type=click.Path(exists=True), metavar='<PATH>')

def main(seqs:click.Path):
    with open(seqs, 'r') as handle:
        seqs = SeqIO.parse(handle, 'fasta')
        for seq in seqs:
            print('>%s \n %s' %(seq.id, hashSeqs(str(seq.seq))))


if __name__ == '__main__':
    main()
