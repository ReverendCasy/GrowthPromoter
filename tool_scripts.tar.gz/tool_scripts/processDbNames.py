#!/usr/bin/env python3

from Bio import SeqIO
from hasher import hashSeqs
from multiprocessing import Pool
from typing import Generator

import click

"""
Restores IPG IDs in the IPG FASTA file
"""

def parseNames(file: Generator)->dict:
    output = dict()
    for line in file:
        line = line.strip('\n').strip('\r')
        line = line.split('\t')
        output[line[1]] = line[0]
    return output

def assignNames(file: Generator, names: dict)->dict:
    output = dict()
    for seq in file:
        new_seq = hashSeqs(str(seq.seq))
        id = names[seq.id.split('.')[0]]
        output[new_seq] = id
    return output


@click.command()
@click.argument('seqs', type=click.Path(exists=True), metavar='<PATH>')
@click.argument('names', type=click.Path(exists=True), metavar='<PATH>')

def main(seqs, names):
    with open(seqs, 'r') as handle1:
        seqs = SeqIO.parse(handle1, 'fasta')
        with open(names, 'r') as handle:
            names = parseNames(handle)
            result = assignNames(seqs, names)
    print(result)


if __name__ == '__main__':
    main()
