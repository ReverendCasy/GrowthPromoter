#!/usr/bin/env python3

from Bio import SeqIO
from hasher import hashSeqs
from processDbNames import parseNames, assignNames
from searchSeqs import multiSearch, singleCoreSearch
from typing import *

import click
import logging
import os

"""
The main script
"""



@click.command()
@click.argument('db', type=click.Path(exists=True),
 metavar='[SUBJECT]')
@click.argument('q', type=click.Path(exists=True),
 metavar='[QUERY]')
@click.option('--names', '-n',
 help='Provide an IPG-ProteinId TSV table', type=click.Path(exists=True),
 metavar='<PATH>')
@click.option('--threads', '-t',
 help='Specify the number of threads. If not specified, the code will run in single process',
 type=int, metavar='<INT>')

def main(db, q, names, threads):
    logging.basicConfig(format=f'{asctime} {levelname}: {messagee}')
    with open(db, 'r') as handle:
        logging.info('Initializing database')
        db = SeqIO.parse(handle, 'fasta')
        if names:
            logging.info('Loading IPG IDs')
            with open(names, 'r') as handle1:
                names = parseNames(handle1)
                database = assignNames(db, names)
        else:
            logging.warning('IPG IDs were not provided; default sequence identifiers will be used')
            database = dict()
            logging.info('Hashing database sequences')
            for seq in db:
                logging.info(f'Logging sequence {seq.id}')
                hash = hashSeqs(str(seq.seq))
                database[hash] = seq.id
            del db
    with open(q, 'r') as handle2:
        logging.info('Initializing query sequences')
        q = SeqIO.parse(handle2, 'fasta')
        query = set() # should it be converted directly to Queue?
        logging.info('Hashing query sequences')
        for seq in q:
            logging.info(f'Hashing sequence {seq.id}')
            query.add(hashSeqs(str(seq.seq)))
        del q
        total = len(query)
    if not threads:
        logging.info('Sequence search is running in single thread mode')
        present = singleCoreSearch(query, set(database.keys()))
    else:
        logging.info(f'Sequence search is running in {threads} threads')
        present = multiSearch(query, set(database.keys()), threads)
    logging.info('Search complete')
    click.echo(f'{len(present)} of {total} were found in the database')
    click.echo('The present IPGs are:')
    for id in present:
        click.echo(database[id])

if __name__ == '__main__':
    main()

