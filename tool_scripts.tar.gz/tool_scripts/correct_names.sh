#!/usr/bin/zsh

sed -i -E 's/(>)[a-z|]*([_A-Z0-9]*.[0-9]).*/\1\2/g' $1
